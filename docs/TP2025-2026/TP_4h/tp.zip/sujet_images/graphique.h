#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <stdlib.h>     
#include <time.h>

typedef unsigned char petit_entier ;

// Nos types
typedef SDL_Surface * image ;
typedef struct couleur {
  uint8_t r,v,b ;
} couleur ;

extern SDL_Window * gWindow ;

//Screen dimension constants
#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480
#define HAUTEUR_FENETRE SCREEN_HEIGHT
#define LARGEUR_FENETRE SCREEN_WIDTH

extern int initialise;

void demarre_graphique();
void arrete_graphique();
image  charge_image(const char * chemin);
int largeur_image(image img);
int hauteur_image(image img);
couleur couleur_du_pixel(const image  img, const int X, const int Y);
void libere_image(image img);
void affiche_image(image img);
image couleurs_vers_image(couleur * c, int largeur, int hauteur);
int nombre_aleatoire(int maxi);
