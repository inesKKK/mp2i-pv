#include <stdio.h>
#include <math.h>
#include "graphique.h"

int main () {
  demarre_graphique();
  arrete_graphique();
  return 0;
}
